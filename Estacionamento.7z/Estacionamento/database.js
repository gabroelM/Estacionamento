import dotenv from 'dotenv';
import { Sequelize } from 'sequelize';

dotenv.config();

const database = new Sequelize(process.env.DATABASE, {
  dialect: 'postgres',
  logging: false
});

try {
  await database.authenticate();
  console.log('Conectado com sucesso ao banco de dados');
} catch (erro) {
  console.log('Erro na conexão:', erro);
}

export { database };
