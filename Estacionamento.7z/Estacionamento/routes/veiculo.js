import express from 'express';
import { criarVeiculo, listarVeiculos } from '../controllers/veiculo.js';

const router = express.Router();

router.post('/api/veiculos', criarVeiculo);
router.get('/api/veiculos', listarVeiculos);

export default router;
