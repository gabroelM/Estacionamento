import express from 'express';
import { registrarEntrada, registrarSaida } from '../controllers/acesso.js';

const router = express.Router();

// Cria um novo acesso (entrada)
router.post('/api/controller/acesso', registrarEntrada);

// Atualiza o acesso com horário de saída
router.put('/api/controller/acesso/:id', registrarSaida);

export default router;