import express from 'express';
import { listarEstacionamentos, criarEstacionamento } from '../controllers/estacionamento.js';

const router = express.Router();

router.get('/api/estacionamento', listarEstacionamentos);
router.post('/api/estacionamento', criarEstacionamento);

export default router;
