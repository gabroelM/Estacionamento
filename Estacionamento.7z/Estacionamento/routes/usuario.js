import express from 'express';
import { criarUsuario, listarUsuarios } from '../controllers/usuario.js';

const router = express.Router();

router.post('/api/usuarios', criarUsuario);
router.get('/api/usuarios', listarUsuarios);

export default router;