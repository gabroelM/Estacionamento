import { veiculo as VeiculoModel } from '../models/veiculo.js';

export const criarVeiculo = async (req, res) => {
  try {
    const novoVeiculo = await VeiculoModel.create(req.body);
    res.status(201).json(novoVeiculo);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
};

export const listarVeiculos = async (req, res) => {
  try {
    const veiculos = await VeiculoModel.findAll();
    res.json(veiculos);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};