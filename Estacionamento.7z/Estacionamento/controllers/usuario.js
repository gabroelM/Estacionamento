import { usuario as UsuarioModel } from '../models/usuario.js';

export const criarUsuario = async (req, res) => {
  try {
    const novoUsuario = await UsuarioModel.create(req.body);
    res.status(201).json(novoUsuario);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
};

export const listarUsuarios = async (req, res) => {
  try {
    const usuarios = await UsuarioModel.findAll();
    res.json(usuarios);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};