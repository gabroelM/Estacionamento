import { acesso as AcessoModel } from '../models/acesso.js';

export const registrarEntrada = async (req, res) => {
  try {
    const acesso = await AcessoModel.create({
      horario_entrada: new Date(),
      usuario_id: req.body.usuario_id,
      estacionamento_id: req.body.estacionamento_id
    });
    res.status(201).json(acesso);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
};

export const registrarSaida = async (req, res) => {
  try {
    const acesso = await AcessoModel.findByPk(req.params.id);
    if (!acesso) return res.status(404).json({ erro: 'Acesso não encontrado' });

    acesso.horario_saida = new Date();
    await acesso.save();
    res.json(acesso);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
};