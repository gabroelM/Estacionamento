import { estacionamento as EstacionamentoModel } from '../models/estacionamento.js';

export const listarEstacionamentos = async (req, res) => {
  try {
    const lista = await EstacionamentoModel.findAll();
    res.json(lista);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const criarEstacionamento = async (req, res) => {
  try {
    const novo = await EstacionamentoModel.create(req.body);
    res.status(201).json(novo);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
};