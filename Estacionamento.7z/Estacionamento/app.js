import express from 'express';
import cors from 'cors';
import { database } from './database.js';
import acesso from './routes/acesso.js';
import usuario from './routes/usuario.js';
import veiculo from './routes/veiculo.js';
import estacionamento from './routes/estacionamento.js';
import './models/associations.js';

// Inicializa o aplicativo Express
const app = express();

// Configura o middleware
app.use(cors());
app.use(express.json()); // Para interpretar JSON no corpo das requisições

// Define as rotas
app.use('/api/usuarios', usuario);
app.use('/api/veiculos', veiculo);
app.use('/api/acessos', acesso);
app.use('/api/estacionamento', estacionamento);

// Middleware para capturar erros não tratados
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ erro: 'Erro interno no servidor' });
});

// Função para iniciar o servidor
async function startServer() {
  try {
    await database.authenticate(); // Verifica a conexão com o banco de dados
    console.log('Conexão com o banco de dados bem-sucedida.');
    await database.sync({ alter: true }); // Sincroniza os modelos com o banco de dados
    app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
  } catch (err) {
    console.error('Erro ao iniciar o servidor:', err);
  }
}

startServer();

export default app;