import { DataTypes } from 'sequelize';
import { database } from '../database.js';

const acesso = database.define('acesso', {
  id_acesso: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  horario_entrada: {
    type: DataTypes.DATE,
    allowNull: false
  },
  horario_saida: DataTypes.DATE
}, {
  tableName: 'acesso',
  timestamps: false
});

export { acesso };
