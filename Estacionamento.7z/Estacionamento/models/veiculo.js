import { DataTypes } from 'sequelize';
import { database } from '../database.js';

const veiculo = database.define('veiculo', {
  id_veiculo: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  modelo: DataTypes.STRING,
  cor: DataTypes.STRING,
  placa: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  }
}, {
  tableName: 'veiculo',
  timestamps: false
});

export { veiculo };
