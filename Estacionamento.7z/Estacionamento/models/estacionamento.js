import { DataTypes } from 'sequelize';
import { database } from '../database.js';

const estacionamento = database.define('estacionamento', {
  id_estacionamento: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  vagas: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  status: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: 'estacionamento',
  timestamps: false
});

export { estacionamento };
 
 