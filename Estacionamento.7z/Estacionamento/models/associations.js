import { usuario } from './usuario.js';
import { veiculo } from './veiculo.js';
import { acesso } from './acesso.js';
import { estacionamento } from './estacionamento.js';

// Relacionamentos

usuario.hasOne(veiculo, { foreignKey: 'usuario_id' });
veiculo.belongsTo(usuario, { foreignKey: 'usuario_id' });

usuario.hasMany(acesso, { foreignKey: 'usuario_id' });
acesso.belongsTo(usuario, { foreignKey: 'usuario_id' });

estacionamento.hasMany(acesso, { foreignKey: 'estacionamento_id' });
acesso.belongsTo(estacionamento, { foreignKey: 'estacionamento_id' });
